<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Store: Signup page</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel&family=Lato&family=Ubuntu&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/signup.css">


</head>
<body>
    <img src="./img/loading.gif" class="loader" alt="">
   <section class="form-section">
    <form class="form-container" method="POST" action="./signup_script.php">
        <div class="form">
            <h1 class="form-heading">new here,  sign up here</h1>  
            <input type="text" autocomplete="off" id="name" placeholder="name" name="username">
            <input type="email" autocomplete="off" id="email" placeholder="email" name="email">
            <input type="password" autocomplete="off" id="password" placeholder="password" name="password">
            <span class="error">**this is an error</span>
            <div>
                <input type="checkbox"  class="checkbox" id="tac">
                <label for="terms-and-cond" class="label-text"> Agree to our <a href=" ">terms and conditions</a></label>
            </div>
            <button class="submit-btn" name="submit">Signup</button>
            <a href="./login.php" class="other-form-link">Already have an account? Login here.</a>
        </div>
        <img src="./img/back4.jpg" class="form-img" alt="">
    </form>
   </section>

   <script src="js/form.js"></script>  
   <script src="js/common.js"></script>  

</body>
</html>