<?php

session_start();

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Online store-Home page </title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cinzel&family=Lato&family=Ubuntu&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="./css/style.css">
        <link rel="stylesheet" href="./css/home.css">

    </head>
    <body>
        <!--NAVBAR IN nav.js file-->
        <nav class="navbar"> </nav>
        <!--header section-->

        <header class="hero-section">
          <div class="content">
            <img src='./img/llogo.png' class="logo" alt="">
            <p class="sub-heading">
            <?php 
                if(isset($_SESSION["username"])){
                    echo "Welcome ", $_SESSION["username"], " !";
                }
                else{
                    echo "IT's TIME TO BE CLASSY !";
                }  
            ?>
            </p>
          </div>
        </header>
        <!-- cards container for favourites-->
        <section class="product">
            <h2 class="product-category">Our best-sellers </h2>
            <button class="pre-btn"><img src="./img/arrow.png" alt=""></button>
            <button class="next-btn"><img src="./img/arrow.png" alt=""></button>
            <div class="product-container">
              <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/product image 1.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card2.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a>
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card5.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card4.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card3.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card6.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card8.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card1.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 


            </div>
        </section>
      <!-- collections-->
        <section class="collection-container">
            <a href="./women.php" class="collection">
                <img src="./img/women-collection.png" alt="">
                <p class="collection-title">Women<br> apparels</p>
            </a>
            <a href="./men.php" class="collection">
                <img src="./img/men-collection.png" alt="">
                <p class="collection-title">Men<br> apparels</p>
            </a>
            <a href="./accessories.php" class="collection">
                <img src="./img/accessories-collection.png" alt="">
                <p class="collection-title">Accessories</p>
            </a>
        </section>
            

        <!-- cards container for shirts-->
        <section class="product">
            <h2 class="product-category">Shirts </h2>
            <button class="pre-btn"><img src="./img/arrow.png" alt=""></button>
            <button class="next-btn"><img src="./img/arrow.png" alt=""></button>
            <div class="product-container">
              <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt1.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt2.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a>
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt8.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt4.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt5.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt6.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt7.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/shirt3.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 


            </div>
        </section>

        <!-- cards container for shoes-->
        <section class="product">
            <h2 class="product-category">Shoes </h2>
            <button class="pre-btn"><img src="./img/arrow.png" alt=""></button>
            <button class="next-btn"><img src="./img/arrow.png" alt=""></button>
            <div class="product-container">

                <a href="./product.php" class="product-card">
                    <div class="product-image">
                        <span class="discount-tag"> 50% off</span>
                        <img src='./img/card9.png' class="product-thumb" alt="">
                        <button class="card-btn">Add to wishlist</button>
                    </div>
                    <div class="product-info">
                        <h2 class="product-brand">Brand</h2>
                        <p class="product-short-desc">A short line about the cloth..</p>
                        <span class="price">$20</span><span class="actual-price">$40</span>
                    </div>
                </a>

            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card11.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a>
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card12.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card15.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card13.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card14.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card10.png' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 
            <a href="./product.php" class="product-card">
                <div class="product-image">
                    <span class="discount-tag"> 50% off</span>
                <img src='./img/card16.jpg' class="product-thumb" alt="">
                <button class="card-btn">Add to wishlist</button>
                </div>
                <div class="product-info">
                    <h2 class="product-brand">Brand</h2>
                    <p class="product-short-desc">A short line about the cloth..</p>
                    <span class="price">$20</span><span class="actual-price">$40</span>
                </div>

            </a> 


            </div>
        </section>

        <!--Footer-->
        <footer></footer>
        
        <script src="./js/nav.js"></script>
        <script src="./js/homejs.js"></script>
        <script src="./js/footer.js"></script>
    
    </body>

</html>