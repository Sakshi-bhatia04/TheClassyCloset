const createNav = () => {
  let nav = document.querySelector('.navbar');

  nav.innerHTML = `
  <div>
        <div class="nav">
        <a href="./index.php">
          <img src="./img/brandlogoc.png" class="brand-logo alt= "">
        </a>
        <div class="nav-items">
            <div class="search">
              <input type="text" class="search-box" placeholder="Search your product here">
              <button class="searchbtn">Search</button>
            </div>
            <a href="./signup.php"><img src="./img/user.png" alt=""></a>
            <a href="#"><img src="./img/cart.png" alt=""></a>
        </div>
      </div>
      <ul class="links-container ">
      <li class="link-item"> <a href="./index.php" class="link active">Home</a></li>
      <li class="link-item"> <a href="./women.php" class="link">Women</a></li>
      <li class="link-item"> <a href="./men.php" class="link">Men</a></li>
      <li class="link-item"> <a href="./kids.php" class="link">Kids</a></li>
      <li class="link-item"> <a href="./accessories.php" class="link">Accessories</a></li>

      </ul>
      </div>
      `;
}

createNav();
