const createFooter = () => {
    let footer = document.querySelector('footer');
  
    footer.innerHTML = `
    <div class="footer-content">
            <img src="./img/llogo.png" class="logo" alt="">
            <div class="footer-ul-containers">
                <ul class="category">
                    <li class="category-title">Men</li>
                    <li> <a href="#" class="footer-link">t-shirts</a> </li>
                    <li> <a href="#" class="footer-link">sweatshirts</a> </li>
                    <li> <a href="#" class="footer-link">Shirts</a> </li>
                    <li> <a href="#" class="footer-link">Jeans</a> </li>
                    <li> <a href="#" class="footer-link">Trousers</a> </li>
                    <li> <a href="#" class="footer-link">Shoes</a> </li>
                    <li> <a href="#" class="footer-link">casuals</a> </li>
                    <li> <a href="#" class="footer-link">Formals</a> </li>
                    <li> <a href="#" class="footer-link">Sports</a> </li>
                    <li> <a href="#" class="footer-link">Watch</a> </li>

                </ul>
                <ul class="category">
                    <li class="category-title">Women</li>
                    <li> <a href="#" class="footer-link">t-shirts</a> </li>
                    <li> <a href="#" class="footer-link">hoodies</a> </li>
                    <li> <a href="#" class="footer-link">Shirts</a> </li>
                    <li> <a href="#" class="footer-link">Jeans</a> </li>
                    <li> <a href="#" class="footer-link">Trousers</a> </li>
                    <li> <a href="#" class="footer-link">Heels</a> </li>
                    <li> <a href="#" class="footer-link">casuals</a> </li>
                    <li> <a href="#" class="footer-link">Formals</a> </li>
                    <li> <a href="#" class="footer-link">Ethnic</a> </li>
                    <li> <a href="#" class="footer-link">Western</a> </li>

                </ul>
            </div>
           
           </div>
           <p class="footer-title"> About company</p>
           <p class="info"> TheClassyCloset is a one stop shop for all your fashion and lifestyle needs. Being India's largest e-commerce store for fashion and
             lifestyle products, we aims at providing a hassle free and enjoyable shopping experience to shoppers across the country with the widest range 
             of brands and products on its portal. The brand is making a conscious effort to bring the power of fashion to shoppers with an array of the latest and trendiest
              products available in the country.</p> 
              <p class="info">Support emails - help@classycloset.com,
                customersupport@classycloset.com </p>
              <p class="info">Telephone - 150 00 00  001, 150 00 00 002</p>
              <div class="footer-social-container">
                <div>
                    <a href="#" class="social-link">Terms & services</a>
                    <a href="#" class="social-link">Privacy page</a>

                </div>
                <div>
                    <a href="#" class="social-link">Instagram</a>
                    <a href="#" class="social-link">Facebook</a>
                    <a href="#" class="social-link">Twitter</a>

                </div>

              </div>
              <p class="footer-credit">TheClassyCloset, The best solution for all your shopping needs ! </p>
      `;
}

createFooter();
