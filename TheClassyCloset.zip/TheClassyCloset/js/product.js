const productImages = document.querySelectorAll(".product-images img");
const productImageSlide = document.querySelector(".image-slider");

let activeImageSlide = 0;

productImages.forEach((item, i) => {
    item.addEventListener('click',() => {
        productImages[activeImageSlide].classList.remove('active');
        item.classList.add('active');
        // image_URL = "http://127.0.0.1:5501/".length + 10;
        // image_URL = item.src.slice(image_URL);
        image_URL = item.src;
        productImageSlide.style.backgroundImage = `url("${image_URL}")`;
        activeImageSlide = i;
    })
})  



//toggle size buttons

const sizeBtns = document.querySelectorAll('.size-radio-btn');
let checkedBtn = 0;
sizeBtns.forEach((item, i) => {
    item.addEventListener('click', () => {
    sizeBtns[checkedBtn].classList.remove('check');
    item.classList.add('check');
    checkedBtn = i;
    })
})
