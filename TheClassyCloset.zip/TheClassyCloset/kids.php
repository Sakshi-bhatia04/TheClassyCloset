<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results for </title>
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/style.css">

    <link rel="stylesheet" href="./css/search.css">
</head>

<body>
    <nav class="navbar"></nav>
    <section class="search-results">
        <h2 class="heading"> search results for <span>kids :)</span></h2>
        <div class="product-container">
            <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid1.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid2.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>


          </div>
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid3.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid4.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid5.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid6.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid7.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid8.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid9.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid10.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid11.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid12.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/kid1.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid14.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid15.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/kid13.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   


          </div>

    </section>
    <footer></footer>
    <script src="./js/nav.js"></script>
    <script src="./js/footer.js"></script>
    
    
</body>
</html>