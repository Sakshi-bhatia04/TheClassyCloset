<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results for </title>
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/style.css">

    <link rel="stylesheet" href="./css/search.css">
</head>

<body>
    <nav class="navbar"></nav>
    <section class="search-results">
        <h2 class="heading"> search results for <span>women apparels :)</span></h2>
        <div class="product-container">
            <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 15% off</span>
              <img src='./img/card1.png' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">ZARA</h2>
                  <p class="product-short-desc">A floral green dress</p>
                  <span class="price">₹999</span><span class="actual-price">₹1400</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 20% off</span>
              <img src='./img/card21.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">HM</h2>
                  <p class="product-short-desc">A pair of denims</p>
                  <span class="price"> ₹2000</span><span class="actual-price"> ₹2500</span>
              </div>


          </div>
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 20% off</span>
            <img src='./img/card17.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">LUCKY</h2>
                <p class="product-short-desc">partywear dress in red</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/card18.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">ZARA</h2>
                <p class="product-short-desc">A one-piece western dress</p>
                <span class="price"> ₹2000</span><span class="actual-price"> ₹4000</span>
            </div>

        </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/card22.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">ahishka</h2>
                  <p class="product-short-desc">Black crop top in cotton</p>
                  <span class="price"> ₹999</span><span class="actual-price"> ₹2000</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 10% off</span>
              <img src='./img/card4.png' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">ZARA</h2>
                  <p class="product-short-desc">Pink single dress solid</p>
                  <span class="price"> ₹3050</span><span class="actual-price"> ₹4500</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/formals1.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/shirt6.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/shirt8.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/card23.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/card20.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/card24.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/card25.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/card27.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/card28.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/formals1.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   


          </div>

    </section>
    <footer></footer>
    <script src="./js/nav.js"></script>
    <script src="./js/footer.js"></script>
    
    
</body>
</html>