<?php

    //used for validating the signup scripts...
    include_once("./db_connect.php");

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $submit = $_POST['submit'];

    if(isset($submit)){
        //submit button was pressed.

        //make it right.
        $sql = "SELECT * FROM `users` WHERE `username` = '" . $username. "';";
        $users = mysqli_query($con, $sql); 
        $row = mysqli_fetch_array($users, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($users); 

        if($count>0){
            echo "Already user exists with same username. <br> <a href='./login.html'>Click here to login</a>";
        }
        else{

            //ok now we need to insert this user into the database.
            //make it right.

            $sql = "INSERT INTO `users`(username, email, password) VALUES('" . $username . "', '" . $email . "', '" . $password ."')";
            $status = mysqli_query($con, $sql); 
            
            echo $sql;
            if($status == TRUE ){
                echo "user inserted successfully now you can login.";
                // Start the session
                session_start();
                $_SESSION["username"] = $username;
                header("Location: ./index.php");
                exit;
            }
            else{
                echo "somthing wrong happend with database.";
            }
        }
    }
?>