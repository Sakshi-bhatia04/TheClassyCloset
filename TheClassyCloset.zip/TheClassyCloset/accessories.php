<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results for </title>
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/style.css">

    <link rel="stylesheet" href="./css/search.css">
</head>

<body>
    <nav class="navbar"></nav>
    <section class="search-results">
        <h2 class="heading"> search results for <span>accessories :)</span></h2>
        <div class="product-container">
            <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/acc1.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/acc2.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>


          </div>
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/acc3.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/scrunchies1.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/acc4.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/acc5.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/acc6.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/scrunchies2.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/acc7.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/acc8.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/acc9.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/acc10.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag"> 50% off</span>
              <img src='./img/acc11.jpg' class="product-thumb" alt="">
              <button class="card-btn">Add to wishlist</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Brand</h2>
                  <p class="product-short-desc">A short line about the cloth..</p>
                  <span class="price">$20</span><span class="actual-price">$40</span>
              </div>

          </div>   
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/acc12.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/acc13.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   
        <div class="product-card">
            <div class="product-image">
                <span class="discount-tag"> 50% off</span>
            <img src='./img/acc14.jpg' class="product-thumb" alt="">
            <button class="card-btn">Add to wishlist</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">Brand</h2>
                <p class="product-short-desc">A short line about the cloth..</p>
                <span class="price">$20</span><span class="actual-price">$40</span>
            </div>

        </div>   


          </div>

    </section>
    <footer></footer>
    <script src="./js/nav.js"></script>
    <script src="./js/footer.js"></script>
    
    
</body>
</html>